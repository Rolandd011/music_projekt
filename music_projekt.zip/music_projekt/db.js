import sqlite3 from 'sqlite3';

const db = new sqlite3.Database('albums.db');

db.serialize(() => {
  db.run(`
    CREATE TABLE IF NOT EXISTS albums (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      band TEXT NOT NULL,
      title TEXT NOT NULL,
      release_year INTEGER,
      genre TEXT
    )
  `);
});

export default db;
