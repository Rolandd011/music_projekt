import express from 'express';
import bodyParser from 'body-parser';
import db from './db.js';
import path from 'path';
import { fileURLToPath } from 'url';

const app = express();
const PORT = 3000;

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
app.use(express.static(path.join(__dirname, 'public')));
app.use(bodyParser.json());

app.get('/api/albums', (req, res) => {
  db.all('SELECT * FROM albums', (err, rows) => {
    if (err) return res.status(500).json({ error: err.message });
    res.json(rows);
  });
});

app.get('/api/albums/:id', (req, res) => {
  db.get('SELECT * FROM albums WHERE id = ?', [req.params.id], (err, row) => {
    if (err) return res.status(500).json({ error: err.message });
    res.json(row);
  });
});

app.post('/api/albums', (req, res) => {
  const { band, title, release_year, genre } = req.body;
  db.run(
    'INSERT INTO albums (band, title, release_year, genre) VALUES (?, ?, ?, ?)',
    [band, title, release_year, genre],
    function (err) {
      if (err) return res.status(500).json({ error: err.message });
      res.json({ id: this.lastID });
    }
  );
});

app.put('/api/albums/:id', (req, res) => {
  const { band, title, release_year, genre } = req.body;
  db.run(
    'UPDATE albums SET band = ?, title = ?, release_year = ?, genre = ? WHERE id = ?',
    [band, title, release_year, genre, req.params.id],
    function (err) {
      if (err) return res.status(500).json({ error: err.message });
      res.json({ updated: this.changes });
    }
  );
});

app.delete('/api/albums/:id', (req, res) => {
  db.run('DELETE FROM albums WHERE id = ?', [req.params.id], function (err) {
    if (err) return res.status(500).json({ error: err.message });
    res.json({ deleted: this.changes });
  });
});

app.listen(PORT, () => {
  console.log(`Szerver fut: http://localhost:${PORT}`);
});
